# Pedir al usuario que ingrese tres números
numero1 = float(input("Ingrese el primer número: "))
numero2 = float(input("Ingrese el segundo número: "))
numero3 = float(input("Ingrese el tercer número: "))

# Calcular el promedio
promedio = (numero1 + numero2 + numero3) / 3

# Mostrar el resultado en pantalla
print("El promedio de los tres números es:", promedio)
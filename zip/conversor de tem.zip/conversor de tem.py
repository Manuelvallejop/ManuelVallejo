temp_celcius = float(input("Ingrese la tempreratura en celcius:  "))
temp_fahrenheit = temp_celcius * 9 // 5 + 32
print("La temperatura en grados Fahrenheit es:  ", temp_fahrenheit) 
